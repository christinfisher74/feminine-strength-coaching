Feminine Strength Co. — Master Client Platform v2 (Coach Hub improvements)

Files included:
- index.html: app shell
- app.js: master platform application and improved Coach Hub client detail view
- styles.css: cream/forest visual styling and responsive programming tables
- config.js: existing Supabase project URL and publishable key from the repository source

Improvements in this package:
- Coach client view includes counts for assigned workouts, completed workouts, and coach notes.
- Workout assignments expand into exercise-level programming details: exercise name, sets/reps/duration/rest, coaching cues, and demo links when those fields exist.
- Completion status and schedule are visible; completed workouts remain in the list rather than being mixed into a new assignment.
- Coach notes are displayed with private/client-visible labels based on the existing private_to_coach field.
- Client selection still comes from coach_clients joined to clients. No client names or client-specific tables are hard-coded.
- Existing Supabase schema/table names are retained; this package does not run database migrations or change database records.

Deployment:
1. Download and unzip the package.
2. In the GitHub repository, replace index.html, app.js, styles.css, and config.js with these files (or upload them into the same repository root).
3. Commit the changes and wait for GitHub Pages to redeploy.
4. Sign in and test with the coach account.

Important:
- This is a source package, not a live deployment. GitHub and Supabase have not been changed by generating it.
- Coach note visibility still depends on the existing Supabase Row Level Security policies. Confirm that coach access is allowed by your current policies before relying on private notes.
- Leanne will appear only if her existing clients record is linked to your coach account in coach_clients. No new records are created here.
- The JavaScript syntax was checked locally. Live Supabase behavior was not tested in this environment.
